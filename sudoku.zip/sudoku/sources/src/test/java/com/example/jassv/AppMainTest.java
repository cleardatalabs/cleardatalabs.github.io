package com.example.jassv;

import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class AppMainTest {

    private AppMain appMain;
    private FileReader fileReader;
    private SudokuValidator sudokuValidator;

    @Before
    public void setUp() {
        fileReader = mock(FileReader.class);
        sudokuValidator = mock(SudokuValidator.class);
        appMain = new AppMain(fileReader, sudokuValidator);
    }

    @Test
    public void runWithInvalidArguments() {
        int res = appMain.run(new String[0]);
        assertNotEquals(0, res);
    }

    @Test
    public void runSuccess() {
        int res = appMain.run(new String[] {"test.csv"});
        assertEquals(0, res);
    }

    @Test
    public void runWithFileReadError() throws IOException {
        when(fileReader.readFile(anyString())).thenThrow(new IOException());

        int res = appMain.run(new String[] {"test.csv"});
        assertNotEquals(0, res);
    }

    @Test
    public void runFailedValidation() {
        doThrow(new IllegalArgumentException()).when(sudokuValidator).validate(any());

        int res = appMain.run(new String[] {"test.csv"});
        assertNotEquals(0, res);
    }
}