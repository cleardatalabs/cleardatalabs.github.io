package com.example.jassv;

import org.junit.Before;
import org.junit.Test;

public class SudokuValidatorTest {

    private SudokuValidator validator;

    private static final int[][] WRONG_SIZE = {{1,2,3},{3,4,5},{6,7,8}};

    private static final int[][] OUT_OF_RANGE = {
            {5,3,4,6,7,8,9,1,2},
            {6,7,2,1,9,5,3,4,8},
            {1,9,8,3,4,2,5,6,7},
            {8,5,9,7,6,1,4,2,3},
            {4,2,6,8,5,3,7,9,1},
            {7,1,3,9,2,4,8,5,6},
            {9,6,1,5,3,7,2,8,4},
            {2,8,7,4,1,9,6,3,5},
            {3,4,5,2,8,6,1,7,10}};

    private static final int[][] NON_UNIQUE = {
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9},
            {1,2,3,4,5,6,7,8,9}};

    private static final int[][] CORRECT_SOLUTION = {
            {5,3,4,6,7,8,9,1,2},
            {6,7,2,1,9,5,3,4,8},
            {1,9,8,3,4,2,5,6,7},
            {8,5,9,7,6,1,4,2,3},
            {4,2,6,8,5,3,7,9,1},
            {7,1,3,9,2,4,8,5,6},
            {9,6,1,5,3,7,2,8,4},
            {2,8,7,4,1,9,6,3,5},
            {3,4,5,2,8,6,1,7,9}};

    @Before
    public void setUp() {
        validator = new SudokuValidator();
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateWrongSize() {
        validator.validate(WRONG_SIZE);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateOutOfRange() {
        validator.validate(OUT_OF_RANGE);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateNonUnique() {
        validator.validate(NON_UNIQUE);
    }

    @Test
    public void validateCorrectSolution() {
        validator.validate(CORRECT_SOLUTION);
    }
}