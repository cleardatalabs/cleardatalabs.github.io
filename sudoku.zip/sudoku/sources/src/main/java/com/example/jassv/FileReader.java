package com.example.jassv;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

/**
 * File reader
 * - reads provided csv
 * - parses it to required format
 */

public class FileReader {

    public int[][] readFile(String fileName) throws IOException {
        Reader reader = Files.newBufferedReader(Paths.get(fileName));
        CSVReader csvReader = new CSVReaderBuilder(reader).build();
        List<String[]> records = csvReader.readAll();

        int[][] res = records.stream()
                .filter(strArr -> strArr.length > 1)
                .map(strArr -> Arrays.stream(strArr).mapToInt(i -> Integer.parseInt(i.trim())).toArray())
                .toArray(int[][]::new);

        return res;
    }
}
