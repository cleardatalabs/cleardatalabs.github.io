package com.example.jassv;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.IntStream;

/**
 * Validator
 * - implements main logic for puzzle solution validation
 */
public class SudokuValidator {

    private final int GRID_SIZE = 9;
    private final int SQUARE_SIZE = 3;
    private final int MAX_VALUE = GRID_SIZE;

    public void validate(int[][] sudoku) {
        checkSize(sudoku);
        checkDataRange(sudoku);
        checkSubZones(sudoku);
    }

    private void checkSize(int[][] sudoku) {
        Consumer <Integer> checkSize = length -> {
            if (length != GRID_SIZE)
                throw new IllegalArgumentException("Invalid grid size (columns)");
        };

        checkSize.accept(sudoku.length);
        Arrays.stream(sudoku).map(i -> i.length).forEach(checkSize);
    }

    private void checkDataRange(int[][] sudoku) {
        for (int[] row : sudoku) {
            for (int value: row) {
                if (value < 1 || value > MAX_VALUE) {
                    throw new IllegalArgumentException("Value is out of allowed range");
                }
            }
        }
    }

    private void checkSubZones(int[][] sudoku) {
        IntStream.range(0, GRID_SIZE).forEach(i -> {
            // rows: 1 * GRID_SIZE
            checkDuplicatesInZone(sudoku, 0, i, GRID_SIZE, i+1);
            // columns: GRID_SIZE * 1
            checkDuplicatesInZone(sudoku, i, 0, i+1, GRID_SIZE);
            // sub-squares: SQUARE_SIZE * SQUARE_SIZE
            checkDuplicatesInZone(sudoku,
                    SQUARE_SIZE * i % GRID_SIZE,
                    SQUARE_SIZE * (i / SQUARE_SIZE),
                    SQUARE_SIZE + SQUARE_SIZE * i % GRID_SIZE,
                    SQUARE_SIZE + SQUARE_SIZE * (i / SQUARE_SIZE));
        });
    }

    private void checkDuplicatesInZone(int[][] sudoku, int startX, int startY, int endX, int endY) {
        Set<Integer> seen = new HashSet<>();
        for (int y = startY; y < endY; y++) {
            for (int x = startX; x < endX; x++) {
                if (!seen.add(sudoku[x][y])) {
                    throw new IllegalArgumentException(
                            String.format("Duplicate value %d detected at pos %d %d", sudoku[x][y], y, x));
                }
            }
        }
    }
}
