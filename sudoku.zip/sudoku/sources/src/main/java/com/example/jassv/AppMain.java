package com.example.jassv;

/**
 * Application main class
 * - implements entry point / runnable routine
 * - creates and injects required dependencies
 * - supports dummy logging
 */
public class AppMain {

    private static AppMain instance;

    private FileReader reader;
    private SudokuValidator validator;

    AppMain(FileReader reader, SudokuValidator validator) {
        this.reader = reader;
        this.validator = validator;
    }

    private static AppMain createInstance() {
        return new AppMain(new FileReader(), new SudokuValidator());
    }

    public static void main(String[] args) {
        instance = createInstance();
        System.exit(instance.run(args));
    }

    public int run(String[] args) {
        if (args.length < 1) {
            log("file name argument is missing");
            return 1;
        }

        try {
            int[][] sudoku = reader.readFile(args[0]);
            validator.validate(sudoku);
        } catch (Exception e) {
            log(e);
            return 1;
        }

        log("All looks good!");
        return 0;
    }

    private static void log(String str) {
        System.out.println(str);
    }

    private static void log(Exception e) {
        System.out.println(e.getClass().toString() + ' ' + e.getMessage());
    }
}
