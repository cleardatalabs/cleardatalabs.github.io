Just Another Sudoku Solution Validator

Directory structure:

1. sources
Maven project, goals available are:

1.1. build from scratch
> mvn clean install

1.2. generate test report 
> mvn surefire-report:report
  
2. runables
Contains binaries manually copied from the project target + bat file + couple of samples
Note: make sure Java is available at PATH, otherwise edit run.bat to set up correct path

> run.bat test.csv

3. reports
Output of surefire-report for unit tests - just open html in browser